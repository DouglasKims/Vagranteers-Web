import random
import math


# cardtest = {
#     'name': "Strike",
#     'abilities': (
#         (1,3, "⚔2"),
#         (4,5, "⚔3"),
#         (6,7, "⚔5"),
#         (8,9, "⚔6"),
#         (10,11, "⚔8"),
#         (12,12, "⚔10"),
#         ),
#     }

# diceroll = random.randint(1,12)
# abilitypos = 0

# for i, ab in enumerate(cardtest['abilities']):
#     if diceroll in range(ab[0],ab[1]):
#         abilitypos = i
#         print(f"Roll of {diceroll} is in position {abilitypos}.\nResult of: {ab[2]}")



# if "⚔" in cardtest['abilities'][abilitypos][2]:
#     pos = cardtest['abilities'][abilitypos][2].find("⚔")
#     dmg = cardtest['abilities'][abilitypos][2][pos+1:pos+2].strip()
    
#     print(f"Card will deal {dmg} damage")

# if "🛡" in cardtest['abilities'][abilitypos][2]:
#     print("Card will shield X damage")




# if diceroll in range(cardtest['abilities'][2][0],cardtest['abilities'][2][1]):
#     print("Roll in range")
# else:
#     print("Roll NOT in range")


# test_thing = ["damage", 5,"shield",3,"all enemies"]

# isdamage = test_thing.index("damage")
# if isdamage >= 0:
#     print("Deal damage")

############ TEST 3 //////

# text2 = "🛡 🎲 0.5x"
# text3 = "🛡 50 All 🔻 + 🎲 +1 + ⚔ 5"

# actions = [p.strip() for p in text3.split(" + ")]
# print(actions)

# for act in actions:

#     pos = act.find("🛡")
#     if act[pos+2] == "🎲":
#         value_end = act.find("x",pos)
#         value = act[pos+3:value_end].strip()
#     else:
#         value = act[pos+1:pos+4].strip()

#     print(value)
# print(pos)

# range(1,3)

# party = [10, 5, 3]


# highest = max(hero for hero in party)
# lowest = min(hero for hero in party)

# number = "10"

# print(highest)
# print(lowest)

# if isinstance(number, str):
#     print("Is STR")
# else:
#     print("Is NOT STR")

# ar2 = [1,2,3,4,5]

# test = ar2.index("x")


###### TEST 4 ///// OBJECT TESTS, changina a value from an object in a different list changes it in the original too

# class diceobj():
#     def __init__(self, value, size):
#         self.value = value
#         self.size = size


# d4 = diceobj(1,4)
# d6 = diceobj(1,6)
# d8 = diceobj(1,8)

# dice1 = [d4, d6, d8]

# dice2 = dice1[:]

# range = dice2[0].size
# dice2[0].value = random.randint(1,range)

# for d in dice1:
#     print(d.value)


######### TEST 5

# arr = [0,1,2,3,4]

# print(arr[0])

# arr.append(arr[0])
# arr.remove(0)

# print(arr)

#### TEST 6


# dict1 = {
#     'name': "Art",
#     'chp': 20
# }

# dict2 = {
#     'name': "Rat",
#     'chp': 8
# }

# dict3 = {
#     'name': "Wolf",
#     'chp': 12
# }

# party = [dict1,dict2,dict3]


# target1 = max(party, key=lambda hero: hero["chp"])
# target2 = min(party, key=lambda hero: hero["chp"])

# print(target1)
# print(target2)

# def sort_chp(e):
#     return e['chp']

# party.sort(key=sort_chp, reverse=True)

# print(party)


######### TEST 7


# floatingcon = []

# floatingcon.append("new")
# floatingcon.append("old")

# if "new" in floatingcon:
#     print("yes")

# hero = {
#     "name": "Man",
#     'wounds': [2,0,1],
#     "isdead": True
# }

# party = [hero]



# # woundcount = sum(n for n in hero['wounds'])
# woundcount = sum(h for h in party if h['isdead'])

# print(woundcount)

###### TEST 8

# def fun():

#     x = 10
#     y = 5

#     return [x,y]

# var = fun()[1]
# print(var)


# arr = [0,1]

# arr.append(2)
# arr.append(3)

# print(arr)


####### TEST 9

# cards_consumables = [
#     {
#         'name': "card cmn",
#         'level': 0
#     },{
#         'name': "card uncmn",
#         'level': 1
#     },{
#         'name': "card rare",
#         'level': 2
#     },{
#         'name': "card leg",
#         'level': 3
#     }
# ]


# consumable_topick = []
# selected_encounter = ['easy', 'Common Consum Card']
# card_rarity = {
#     "common": 0,
#     "uncommon": 1,
#     "rare": 2,
#     "legendary": 3,
# }
# card_rarity_touse = selected_encounter[1].split()[0].lower()

# # while len(consumable_topick) < 3:
# valid_cards = []
# for card in cards_consumables:
#     if card['level'] == card_rarity[card_rarity_touse]:
#         valid_cards.append(card)

# print(valid_cards)

# consumable_topick.insert(0)


######## TEST 10


# act = "Attack 15 + Burn 3 + Daze 2"

# cardacts = []
# for a in act.split(" + "):
#     for i, str in enumerate(a.split()):
#         if i == 0:
#             term = str
#         elif i == 1:
#             value = str

#     cardacts.append([term, value])

# print(cardacts)

######### TEST 11


# var1 = int(13/2)
# var2 = math.ceil(13/2)

# print(var1)
# print(var2)

######## TYEST 14

party_blessings = ["armor_1", "reroll_1",'throw_1', 'exp_1', 'resourceful_1', 'condition_1', 'tough_1', 'heal_1', 'shield_1', 'atk_1']

if "exp_1" in party_blessings:
    print("Experience")
else:
    print("nooo")